<?php
// Start session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "family_feud_game";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Sanitize and validate user input
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Record score after each round
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $playerName = sanitize_input($_POST['playerName']);
    $playerScore = sanitize_input($_POST['playerScore']);
    $gameDate = date('Y-m-d H:i:s');

    $stmt = $conn->prepare("INSERT INTO scores (playerName, score, gameDate) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $playerName, $playerScore, $gameDate);

    if ($stmt->execute()) {
        echo "Score recorded.";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Display leaderboard
function displayLeaderboard($conn) {
    $query = "SELECT playerName, score FROM scores ORDER BY score DESC";
    $result = $conn->query($query);

    echo "<h2>Leaderboard</h2>";
    echo "<table><thead><tr><th>Player</th><th>Score</th></tr></thead><tbody>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>{$row['playerName']}</td><td>{$row['score']}</td></tr>";
    }
    echo "</tbody></table>";
}

mysqli_close($conn);
?>
